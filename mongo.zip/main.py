from pymongo import MongoClient
import sys

conn_str = "mongodb+srv://joemama:joedad@cluster0.ofsfw.mongodb.net/test?retryWrites=true&w=majority"

client = MongoClient(conn_str, serverSelectionTimeoutMS=5000)

db = client.get_database('simple-db')

data = db.simple_data

newuser = {}
accountChecker = input("Do you already have an account with this program (y/n)? ")

if accountChecker == 'n':
    signIn_user_name = input("Username: ")
    signIn_password = input("Password: ")
    newuser['username'] = signIn_user_name
    newuser['password'] = signIn_password
    data.insert_one(newuser)
elif accountChecker == 'y':
    logIn_user_name = input("Login Username: ")
    logIn_password = input("Login Password: ")
    user_password = data.find_one({'password': logIn_password})
    user_name = data.find_one({'username': logIn_user_name})
    try:
        lst_user_pass = list(user_password)
        lst_user_name = list(user_name)
        print("You have successfully logged in!")
    except TypeError:
        print('You either got the username incorrect or the password.')
        sys.exit()

print('--------------------------')
print('Options:')
print('acc details')
print('quit')
print('set note')
print('get note')
print('delete note')
print('hack someone')
print('--------------------------')
inp = input("What would you like to do? ")
print('--------------------------')

while inp:
    if inp == 'quit':
        break
    elif inp == 'acc details':
        acc = data.find_one({'username': logIn_user_name, 'password': logIn_password})
        for document in acc:
            if document == '_id':
                continue
            else:
                print('{}: {}'.format(document, acc[document]))
    elif inp == 'set note':
        note = input('Note: ')
        set_note = {"$set": {"note": note}}
        acc = data.find_one({'username': logIn_user_name, 'password': logIn_password})
        data.update_one(acc, set_note)
        print('Note is set')
    elif inp == 'get note':
        acc = data.find_one({'username': logIn_user_name, 'password': logIn_password})
        for document in acc:
            if document == 'note':
                print(acc[document])
            else:
                continue
    elif inp == 'delete note':
        acc = data.find_one({'username': logIn_user_name, 'password': logIn_password})
        delete_placeholder = {'$set': {'note': ''}}
        data.update_one(acc, delete_placeholder)
        print("Note is deleted")
    elif inp == 'hack someone':
        print("Guess someone's username and we'll display their account details")
        print('If you want to quit, type "quit"')
        print('--------------------------')
        guess = input('Guess: ')
        print('--------------------------')
        while guess:
            acc = data.find_one({'username': guess})
            try:
                for x in acc:
                    if x == '_id':
                        continue
                    else:
                        print('{}: {}'.format(x, acc[x]))
            except TypeError:
                print("Nope, no one chose that username")
            print('--------------------------')
            guess = input("Guess: ")
            print('--------------------------')
            if guess == "quit":
                break
    print('--------------------------')
    inp = input("What would you like to do? ")